
@ua = (3,10,76,23,1,53);

@sortedArray = sort @ua;




$n = @sortedArray;
print "size of the arrray is $n\n";

for($i=0;$i<$n;$i++)
   {
   print "@sortedArray[$i]\n";
   }

#-------------------------
print "\n----------------------\n";
@sortedArray1 = sort numeric @ua;

sub numeric 
	{
    	return $a <=> $b;
	}
	
for($i=0;$i<$n;$i++)
   {
   print "@sortedArray1[$i]\n";
   }	