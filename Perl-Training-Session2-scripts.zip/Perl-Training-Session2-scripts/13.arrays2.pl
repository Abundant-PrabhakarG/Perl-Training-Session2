@array = (1,2,3,5);

print "Size: ",scalar @array,"\n";

print $#array;  
