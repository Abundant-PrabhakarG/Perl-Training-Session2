

print "If condition example\n\n"; 
my $age = 24;
if ($age >= 18) 
   { 
   print "In most countries you can vote.\n";
   }
