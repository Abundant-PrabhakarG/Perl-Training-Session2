#Variables 

$age=28;
if (1<2) 
    {
    my $age=25; 
    print "$age\n"; 
     }
print "$age\n";
