my $a = 10;
 
unless($a <= 0){
   print("a is greater than 0\n")                    
}