use strict;
use warnings;

my $x=10;
print('$x\n');
