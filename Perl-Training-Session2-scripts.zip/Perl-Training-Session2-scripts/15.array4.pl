

@unsortedArray =("Larry", "Curly", "moe");	
@sortedArray = sort { lc($a) cmp  lc($b)} @unsortedArray;

print "@unsortedArray\n"; # prints Larry Curly moe
print "@sortedArray\n";	    # prints Curly Larry moe
