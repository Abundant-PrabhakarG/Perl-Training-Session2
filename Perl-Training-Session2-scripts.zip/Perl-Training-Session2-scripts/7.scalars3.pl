use strict;
use warnings;

my $x = "5";  
my $y = "2cm";  
print $x + $y;
print "\n";
print $x . $y;        
