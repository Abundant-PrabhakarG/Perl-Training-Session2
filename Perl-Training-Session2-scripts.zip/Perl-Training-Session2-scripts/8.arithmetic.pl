
my $x = 5;  
use strict;
use warnings;

my $y = 2;  
print "\nAddition\n";
print $x + $y;   
print "\nSubtraction\n";
print $x - $y;
print "\nMultiplication\n";
print $x * $y;   
print "\nDivision\n";
print $x/$y;   
print "\nModulus\n";
print $x%$y;   
print "\nExponent\n";
print $x**$y; ;   
