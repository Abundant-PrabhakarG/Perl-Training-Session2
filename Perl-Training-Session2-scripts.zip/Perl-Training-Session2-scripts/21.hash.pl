use strict;
use warnings;

# defines country => language hash
my %langs = ( England => 'English',
 France => 'French', 
 Spain => 'Spanish', 
 China => 'Chinese', 
 Germany => 'German');
 
# get language of England
my $lang = $langs{'England'}; # English
print($lang,"\n");

my $lang1 = $langs{'Spain'}; # English
print($lang1,"\n");
