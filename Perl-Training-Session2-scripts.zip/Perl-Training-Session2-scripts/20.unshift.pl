

my @names = ('Foo', 'Bar');
unshift @names, 'Moo';
print "@names\n";     

my @others = ('Darth', 'Vader');
unshift @names, @others;
print "@names\n";    