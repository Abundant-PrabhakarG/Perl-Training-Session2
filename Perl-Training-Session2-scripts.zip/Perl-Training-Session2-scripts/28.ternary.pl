

$apples=1;

$oranges=38;

print "I have $apples ", $apples==1?"apple":"apples", "\n";

print "I have $oranges orange", $oranges==1?"":"s", "\n";
