my $a = 1;
 
unless($a > 0){
   print("a is less than 0\n");                   
}elsif($a == 0){
   print("a is 0\n");                   
}else{
   print("a is greater than 0\n");                    
}