
#decomposing string to array

$var_string = "All,That,Glitters,Is,Not,Gold";

print "$var_string\n";

@string = split(',', $var_string);

print "$string[3]\n";  # This will print Glitters

# combining the elements of array to strings

$string1 = join( ' ', @string );

print "@string\n";
