use strict;
use warnings;

my $x=5;
print "Value of x is: $x\n";
my $y=4;
print "Value of y is: $y\n";

print $x+$y;
print "\n";
print $x.$y;
print "\n";
print $x-$y;
