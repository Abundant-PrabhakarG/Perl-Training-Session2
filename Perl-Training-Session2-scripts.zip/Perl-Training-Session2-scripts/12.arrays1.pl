

my @names = ("Foo", "Bar", "Baz"); 

print "@names[0]\n";      
print "@names[1]\n";
print "@names[2]\n";
print "--@names[3]\n"; 
