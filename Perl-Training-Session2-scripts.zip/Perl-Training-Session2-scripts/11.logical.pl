
$x=5;
if ($x == 5  && $x < 10)
   {print "Value is equal to $x and is less than 10\n";}   
if ($x == 5  || $x > 3 )
   {print "Value is equal to $x and greater than 3\n";} 
