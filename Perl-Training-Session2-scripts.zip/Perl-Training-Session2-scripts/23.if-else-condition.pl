

print "If condition example\n\n"; 
my $age = 16;
if ($age >= 18) 
   { 
   print "Yes you can vote\n";
   }
else
   {
   print "In most countries you can vote.\n";
   }