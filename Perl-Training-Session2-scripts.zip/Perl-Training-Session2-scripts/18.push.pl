

my @names = ('Foo', 'Bar');

print "@names\n";

push @names, 'Moo';

print "@names\n";    

my @others = ('Darth', 'Vader');

push @names, @others;

print "@names\n";     