

my @names = ('Foo', 'Bar', 'Baz');

print "@names\n";     # Foo Bar
my $last_one = pop @names;
   
print "$last_one\n";

print "@names\n"; 