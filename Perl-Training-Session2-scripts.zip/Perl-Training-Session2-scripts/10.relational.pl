
$x=5;
if ($x == 5)
   {print "Value is equal\n";} 
if ($x < 10)
   {print "Value is less than\n";}
if ($x > 3)
   {print "Value is greater than\n";}
