

my @names = ('Foo', 'Bar', 'Moo');

my $first = shift @names;
print "$first\n";    

print "@names\n";    
